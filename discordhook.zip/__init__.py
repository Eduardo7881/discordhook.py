# DiscordHook.py
# Discord Webhook Python Framework
#
# Licensed under MIT License
# Author: EduardoPlayss121

from .core import DiscordWebhook
